from django.contrib import admin
from Accounts.models import Your_CSV
# Register your models here.
admin.site.register(Your_CSV)
